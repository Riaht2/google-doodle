A Pen created at CodePen.io. You can find this one at https://codepen.io/Riaht2/pen/vMQEMZ.

 Blank Google Doodle template. A "stage" for the animations. 